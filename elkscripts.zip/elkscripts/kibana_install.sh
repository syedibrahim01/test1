#!/bin/bash
########################################
#Scrit: kibana_install.sh
#Autor: Vani Singamsetty
#Date: 08/17/2022 First Draft
#Date: 09/06/2022 Added deploy props
########################################

STEP="KIBANA INSTALLATIOn START"
trap onerr ERR

function onerr() {
    RC=$?
    CHECKPOINT=$(date -u '+%FT%H:%M:%SZ')
    echo "${CHECKPOINT} KIBANA installation failed during $STEP with code $RC"
    exit $RC
}

function abort() {
    RETVAL=$1
    shift
    date -u "+%FT%H:%M:%SZ"
    echo "ABORT: $*"
    exit ${RETVAL}
}

function prechecks() {

    date -u "+%FT%H:%M:%SZ"
    echo "##############################################"
    echo "############## Perform prechecks #############"
    echo "##############################################"

    RETVAL=1


    if cat /etc/*release | grep ^NAME | grep CentOS; then
        KBN_EXE=kibana-${KBN_VERSION}-x86_64.rpm
        INSTALL_BIN=`which rpm`
    elif cat /etc/*release | grep ^NAME | grep Red; then
        KBN_EXE=kibana-${KBN_VERSION}-x86_64.rpm
        INSTALL_BIN=`which rpm`
    elif cat /etc/*release | grep ^NAME | grep Fedora; then
        KBN_EXE=kibana-${KBN_VERSION}-x86_64.rpm
        INSTALL_BIN=`which rpm`
    elif cat /etc/*release | grep ^NAME | grep Ubuntu; then
        KBN_EXE=kibana-${KBN_VERSION}-amd64.deb
        INSTALL_BIN=`which apt`
    elif cat /etc/*release | grep ^NAME | grep Debian ; then
        KBN_EXE=kibana-${KBN_VERSION}-amd64.deb
        INSTALL_BIN=`which apt`
    fi

    RETVAL=0
    return ${RETVAL}

}

function setup_exists() {

    date -u "+%FT%H:%M:%SZ"
    echo "##############################################"
    echo "########## Validate existing intallation #####"
    echo "##############################################"

    RETVAL=1

    if [[ -e $KBN_BIN_HOME/kibana ]]; then
        abort 0 "kibana setup already exists in $KBN_BIN_HOME with configs $KBN_CONFIG"
    fi

    RETVAL=0
    return ${RETVAL}

}

function install() {

    date -u "+%FT%H:%M:%SZ"
    echo "###########################################i#############"
    echo "########## Install kibana ######################"
    echo "#########################################################"

    RETVAL=1

    cd $BASEDIR

    if [[ "${BA_PROXY:-}x" != "x" ]]; then
        HTTP_PROXY="${BA_PROXY}"; export HTTP_PROXY
        HTTPS_PROXY="${BA_PROXY}"; export HTTPS_PROXY
    fi

    curl -k -O ${KBN_ARTIFACT_URL}/${KBN_EXE}

    if [[ ! -f "${BASEDIR}/${KBN_EXE}" ]]; then
      abort 1 "$KBN_EXE failed to download."
    fi

    if [[ "${KBN_EXE}" =~ .*"rpm".* ]]; then
       yes | sudo rpm -ivh ${BASEDIR}/${KBN_EXE}
       #sudo chkconfig --add kibana || abort $? "sudo chkconfig --add kibana failed."
    elif [[ "${KBN_EXE}" =~ .*"deb".* ]]; then
       sudo apt install ${BASEDIR}/${KBN_EXE}
    fi

    if [[ -e $KBN_BIN_HOME/kibana ]]; then
        sudo systemctl enable kibana
    else
        abort 1 "kibana failed to install!!"
    fi

    RETVAL=0
    return ${RETVAL}

}

function config() {

  mkdir -p ${KBN_DATA_PATH}/logs/kibana
  mkdir -p ${KBN_DATA_PATH}/kibana_data

  #$KBN_BIN_HOME/kibanakibana keystore create -c $KBN_CONFIG
  #echo 'KIBANA' | $KBN_BIN_HOME/kibana keystore add KBN_USER --force -c $KBN_CONFIG
  #echo 'bitnami' | $KBN_BIN_HOME/kibana keystore add KBN_PWD --force -c $KBN_CONFIG

  if [[ -f $KBN_CONFIG ]]; then
    mv $KBN_CONFIG $KBN_CONFIG.orignal
  fi

  cp -r $BASEDIR/kibana_configs/kibana.yml $KBN_CONF_HOME/
  #ln -s $KBN_CONF_HOME/kibana.yml $KBN_BIN_HOME/config/kibana.yml

  #cp -r $BASEDIR/certs/*.pem $KBN_CONF_HOME/
  #cp -r $BASEDIR/certs/*.crt $KBN_CONF_HOME/

}


function start_process() {

    RETVAL=1

    chown $KBN_USER:$KBN_GROUP ${KBN_DATA_PATH}/kibana_data
    chown $KBN_USER:$KBN_GROUP ${KBN_DATA_PATH}/logs/kibana
    chmod 777 ${KBN_DATA_PATH}/logs/kibana
    chown -R $KBN_USER:$KBN_GROUP $KBN_CONF_HOME

    sudo systemctl start kibana
    sleep 3
    KBN_RUNNIG_STATUS=$(sudo systemctl status kibana | tail -1 | grep Started | wc -l)
    if [[$KBN_RUNNIG_STATUS == 0 ]]; then
        abort 1 "kibana failed to start process, please check manually.."
    else
       echo "###### kibana started successfully."
    fi
    RETVAL=0
    return ${RETVAL}

}

function install_plugins() {

    sudo apt install unzip

    curl  -LO https://github.com/dlumbrer/kbn_network/releases/download/$KBN_VERSION-1/kbn_network-$KBN_VERSION.zip
    if [[ -f kbn_network-$KBN_VERSION.zip ]]; then
      mv kbn_network-$KBN_VERSION.zip $KBN_PLUGINS_HOME
      cd $KBN_PLUGINS_HOME
      unzip kbn_network-$KBN_VERSION.zip
      mv kibana/kbn_network .
      rm -rf kibana kbn_network-$KBN_VERSION.zip
      chown -R $KBN_USER:$KBN_GROUP $KBN_PLUGINS_HOME
      echo "### Installed kbn_network ####"
    else
	echo "### Unable to download kbn_network-$KBN_VERSION.zip, install manually####"
    fi

    curl  -LO https://github.com/uniberg/kbn_sankey_vis/releases/download/$KBN_SANKY_PLUGIN_VERSION/kbnSankeyVis-$KBN_VERSION.zip
    if [[ -f kbnSankeyVis-$KBN_VERSION.zip ]]; then
     mv kbnSankeyVis-$KBN_VERSION.zip $KBN_PLUGINS_HOME
     cd $KBN_PLUGINS_HOME
     unzip kbnSankeyVis-$KBN_VERSION.zip
     mv kibana/kbnSankeyVis .
     rm -rf kibana kbnSankeyVis-$KBN_VERSION.zip 
     chown -R $KBN_USER:$KBN_GROUP $KBN_PLUGINS_HOME
     echo "### Installed kbnSankeyVis ####"
    else
        echo "### Unable to download kbnSankeyVis-$KBN_VERSION.zip, install manually####"
    fi

}

function create_spaces() {

  RETVAL=1

  curl -k -u "elastic:$KBN_BOOT_PASS" -XPOST "http://localhost:5601/api/spaces/space" -H 'kbn-xsrf: true' -H 'Content-Type: application/json' -d' { "id": "bluearmor", "name": "BlueArmor", "description" : "BA Gatewaylogs Space", "color": "#9170B8","initials": "BA", "disabledFeatures": [] }'

  curl -k -u "elastic:$KBN_BOOT_PASS" -XPOST "http://localhost:5601/api/spaces/space" -H 'kbn-xsrf: true' -H 'Content-Type: application/json' -d' { "id": "catalina", "name": "Catalina", "description" : "Tomcat logs Space", "color": "#6770B8","initials": "CT", "disabledFeatures": [] }'

    RETVAL=0
    return ${RETVAL}


}


####################### HERE MAIN ##################

set -x
set +e
set -o pipefail

RETVAL=0

export BASEDIR=$( cd $( /usr/bin/dirname $0 ) > /dev/null 2>&1; pwd )

source $BASEDIR/deployment.props

STEP="PERFORM PRECHECKS"
prechecks

STEP="VALIDATE kibana EXISTING INSTALLATION"
setup_exists

STEP="INSTALL kibana"
install

STEP="CONFIGURE kibana"
config

STEP="install plugins"
install_plugins

STEP="START kibana"
start_process

sleep 30

STEP="Create spaces"
create_spaces

STEP="REMOVE TMP FILES"
rm -rf $BASEDIR/${KBN_EXE}

echo "######## Completed the kibana installaion. ##########"

exit ${RETVAL}
